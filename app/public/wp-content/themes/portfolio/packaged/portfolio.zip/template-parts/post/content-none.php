<p><?php echo apply_filters('portfolio_no_posts_text', esc_html_e('Sorry, no posts matched your criteria.', 'portfolio')); ?></p>
