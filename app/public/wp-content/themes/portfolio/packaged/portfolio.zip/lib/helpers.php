<?php 

function portfolio_post_meta() {
    /* Translators: %s: Post Date */
    printf(
        esc_html__('Posted on %s', 'portfolio'),
        '<a href="' . esc_url(get_permalink()) . '"> <time datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) .'</time></a>'
    );
    /* Translators: %s: Post Author */
    printf(
        esc_html__(' By %s', 'portfolio'),
        '<a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . esc_html(get_the_author()) . '</a>'
    );
}

function portfolio_readmore_link() {
    echo '<a class="c-post__readmore" href="' . esc_url(get_permalink()) . '" title="' . the_title_attribute(['echo' => false]) . '">';
    /* Translators: %s: Post Title */
    printf(
        wp_kses(
            __('Read More <span class="u-screen-reader-text">About %s</span>', 'portfolio'),
            [
                'span' => [
                    'class'=> []
                ]
            ]
        ), 
        get_the_title()
    );
    echo '</a>';
}

function portfolio_delete_post() {
    $url = add_query_arg([
        'action' => 'portfolio_delete_post',
        'post' => get_the_ID(),
        'nonce' => wp_create_nonce('portfolio_delete_post_' . get_the_ID())
    ], home_url());
    if(current_user_can('delete_post', get_the_ID())) {
        return "<a href='" . esc_url($url) . "'>" . esc_html__('Delete Post', 'portfolio') . "</a>";
    }
}