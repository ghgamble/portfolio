<?php 

function portfolio_sidebar_widgets() {
    register_sidebar(array(
        'id' => 'primary-sidebar',
        'name' => esc_html__('Primary Sidebar', 'portfolio'),
        'description' => esc_html__('This sidebar appears on the blog posts page.', 'portfolio'),
        'before_widget' => '<section id="%1$s" class="c-sidebar-widget u-margin-bottom-20 %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h5>',
        'after_title' => '</h5>'
    ));
}

$footer_layout = sanitize_text_field(get_theme_mod('portfolio_footer_layout', '3,3,3,3'));
$footer_layout = preg_replace('/\s+/', '', $footer_layout);
$columns = explode(',', $footer_layout);
$footer_bg = portfolio_sanitize_footer_bg(get_theme_mod('portfolio_footer_bg', 'dark'));
$widget_theme = '';
if($footer_bg == 'light') {
    $widget_theme = 'c-footer-widget--dark';
} else {
    $widget_theme = 'c-footer-widget--light';
}

foreach ($columns as $i => $column) {
    register_sidebar(array(
        'id' => 'footer-sidebar-' . ($i + 1),
        'name' => sprintf(esc_html__('Footer Widgets Column %s', 'portfolio'), $i + 1),
        'description' => esc_html__('Footer Widgets', 'portfolio'),
        'before_widget' => '<section id="%1$s" class="c-footer-widget ' . $widget_theme . ' %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h5>',
        'after_title' => '</h5>'
    ));
}

add_action('widgets_init', 'portfolio_sidebar_widgets');