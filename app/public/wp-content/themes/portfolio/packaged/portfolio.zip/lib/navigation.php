<?php

function portfolio_register_menus() {
    register_nav_menus( array(
        'main-menu' => esc_html__('Main Menu', 'portfolio'),
        'footer-menu' => esc_html__('Footer Menu', 'portfolio')
    ) );
}
add_action( 'init', 'portfolio_register_menus' );

function portfolio_aria_hasdropdown($atts, $item, $args) {
    if($args->theme_location == 'main-menu') {
        if(in_array('menu-item-has-children', $item->classes)) {
            $atts['aria-haspopup'] = 'true';
            $atts['aria-expanded'] = 'false';
        }
    }
    return $atts;
}
add_filter( 'nav_menu_link_attributes', 'portfolio_aria_hasdropdown', 10, 3 );

function portfolio_submenu_button($dir = 'down', $title) {
    $button = '<button class="menu-button">';
    $button .= '<span class="u-screen-reader-text menu-button-show">' . sprintf(esc_html__('Show %s submenu', 'portfolio'), $title) . '</span>';
    $button .= '<span aria-hidden="true" class="u-screen-reader-text menu-button-hide">' . sprintf(esc_html__('Hide %s submenu', 'portfolio'), $title) . '</span>';
    $button .= '<i class="fa fa-angle-' . $dir . '" aria-hidden="true"></i>';
    $button .= '</button>';
    return $button;
}

function portfolio_dropdown_icon($title, $item, $args, $depth) {
    if($args->theme_location == 'main-menu') {
        if(in_array('menu-item-has-children', $item->classes)) {
            if($depth == 0) {
                $title .= portfolio_submenu_button('down', $title);
            } else {
                $title .= portfolio_submenu_button('right', $title);
            }
        }
    }
    return $title;
}

add_filter( 'nav_menu_item_title', 'portfolio_dropdown_icon', 10, 4 );