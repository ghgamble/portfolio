<?php 

function portfolio_customize_register($wp_customize) {
    $wp_customize->get_setting('blogname')->transport = 'postMessage';

    $wp_customize->selective_refresh->add_partial('blogname', array(
        // 'settings' => array('blogname')
        'selector' => '.c-header__blogname',
        'container_inclusive' => false,
        'render_callback' => function() {
            bloginfo('name');
        }
    ));
    // General
    $wp_customize->add_section('portfolio_general_options', array(
        'title' => esc_html__('General Options', 'portfolio'),
        'description' => esc_html__('You can change general options from here','portfolio')
    ));
    $wp_customize->add_setting('portfolio_accent_colour', array(
        'default'=> '#20ddae',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'portfolio_accent_colour',
        array(
            'label'    => __('Accent Color', 'portfolio'),
            'section'  => 'portfolio_general_options'
        )
    ));

    $wp_customize->add_setting('portfolio_header_colour', array(
        'default'=> '#222222',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'portfolio_header_colour',
        array(
            'label'    => __('Header Color', 'portfolio'),
            'section'  => 'portfolio_general_options'
        )
    ));

    // Footer
    $wp_customize->selective_refresh->add_partial('portfolio_footer_partial', array(
        'settings' => array('portfolio_footer_bg', 'portfolio_footer_layout'),
        'selector' => '#footer',
        'container_inclusive' => false,
        'render_callback' => function() {
            get_template_part('template-parts/footer/info');
            get_template_part('template-parts/footer/widgets');
        }
    ));

    $wp_customize->add_section('portfolio_footer_options', array(
        'title' => esc_html__('Footer Options', 'portfolio'),
        'description' => esc_html__('You can change footer options from here','portfolio')
    ));

    $wp_customize->add_setting('portfolio_site_info', array(
        'default' => '',
        'sanitze_callback' => 'portfolio_sanitize_site_info',
        'transport' => 'postMessage'
    ));
    $wp_customize->add_control('portfolio_site_info', array(
        'type' => 'text',
        'label' => esc_html__('Site Info', 'portfolio'),
        'section' => 'portfolio_footer_options'
    ));

    $wp_customize->add_setting('portfolio_footer_bg', array(
        'default' => 'dark',
        'transport' => 'postMessage',
        'sanitize_callback' => 'portfolio_sanitize_footer_bg'
    ));
    $wp_customize->add_control('portfolio_footer_bg', array(
        'type' => 'select',
        'label' => esc_html__('Footer Background', 'portfolio'),
        'choices' => array(
            'light' => esc_html__('Light','portfolio'),
            'dark' => esc_html__('Dark','portfolio')
        ),
        'section' => 'portfolio_footer_options'
    ));

    $wp_customize->add_setting('portfolio_footer_layout', array(
        'default' => '3,3,3,3',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
        'validate_callback' => 'portfolio_validate_footer_layout'
    ));
    $wp_customize->add_control('portfolio_footer_layout', array(
        'type' => 'text',
        'label' => esc_html__('Footer Layout', 'portfolio'),
        'section' => 'portfolio_footer_options'
    ));
}
add_action('customize_register', 'portfolio_customize_register');

function portfolio_validate_footer_layout( $validity, $value) {
    if(!preg_match('/^([1-9]|1[012])(,([1-9]|1[012]))*$/', $value)) {
        $validity->add('invalid_footer_layout', esc_html__( 'Footer layout is invalid', 'portfolio' ));
    }
    return $validity;
}

function portfolio_sanitize_footer_bg($input) {
    $valid = array('light', 'dark');
    if(in_array($input, $valid, true)) {
        return $input;
    }
    return 'dark';
}

function portfolio_sanitize_site_info($input) {
    $allowed = array('a' => array(
        'href' => array(),
        'title' => array()
    ));
    return wp_kses($input, $allowed);
}