<?php 

/*
Plugin Name: portfolio metaboxes
Plugin URI: 
Description: Adding metaboxes from portfolio
Version: 1.0.0
Author: Grace Gamble
AuthorURI: https://github.com/ghgamble,
Text Domain: portfolio-metaboxes
Domain Path: /languages
*/

if(!defined('WPINC')) {
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');